<?php
$response = array();
include 'db/db_connect.php';
include 'functions.php';

//Get the input request parameters
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array




//Margarita
//Check for Mandatory parameters
if(isset($input['nazivM']) && isset($input['cijenaM']) && isset($input['kolicinaM']) && isset($input['ukupnoM'])){
	$nazivM = $input['nazivM'];
	$cijenaM = $input['cijenaM'];
	$kolicinaM = $input['kolicinaM'];
	$ukupnoM = $input['ukupnoM'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivM, $cijenaM, $kolicinaM, $ukupnoM);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Capriccosa
//Check for Mandatory parameters
if(isset($input['nazivC']) && isset($input['cijenaC']) && isset($input['kolicinaC']) && isset($input['ukupnoC'])){
	$nazivC = $input['nazivC'];
	$cijenaC = $input['cijenaC'];
	$kolicinaC = $input['kolicinaC'];
	$ukupnoC = $input['ukupnoC'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivC, $cijenaC, $kolicinaC, $ukupnoC);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Funghi
//Check for Mandatory parameters
if(isset($input['nazivF']) && isset($input['cijenaF']) && isset($input['kolicinaF']) && isset($input['ukupnoF'])){
	$nazivF = $input['nazivF'];
	$cijenaF = $input['cijenaF'];
	$kolicinaF = $input['kolicinaF'];
	$ukupnoF = $input['ukupnoF'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivF, $cijenaF, $kolicinaF, $ukupnoF);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Vegetariana
//Check for Mandatory parameters
if(isset($input['nazivV']) && isset($input['cijenaV']) && isset($input['kolicinaV']) && isset($input['ukupnoV'])){
	$nazivV = $input['nazivV'];
	$cijenaV = $input['cijenaV'];
	$kolicinaV = $input['kolicinaV'];
	$ukupnoV = $input['ukupnoV'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivV, $cijenaV, $kolicinaV, $ukupnoV);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Hawaii
//Check for Mandatory parameters
if(isset($input['nazivH']) && isset($input['cijenaH']) && isset($input['kolicinaH']) && isset($input['ukupnoH'])){
	$nazivH = $input['nazivH'];
	$cijenaH = $input['cijenaH'];
	$kolicinaH = $input['kolicinaH'];
	$ukupnoH = $input['ukupnoH'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivH, $cijenaH, $kolicinaH, $ukupnoH);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Bianca
//Check for Mandatory parameters
if(isset($input['nazivB']) && isset($input['cijenaB']) && isset($input['kolicinaB']) && isset($input['ukupnoB'])){
	$nazivB = $input['nazivB'];
	$cijenaB = $input['cijenaB'];
	$kolicinaB = $input['kolicinaB'];
	$ukupnoB = $input['ukupnoB'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivB, $cijenaB, $kolicinaB, $ukupnoB);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Picante
//Check for Mandatory parameters
if(isset($input['nazivP']) && isset($input['cijenaP']) && isset($input['kolicinaP']) && isset($input['ukupnoP'])){
	$nazivP = $input['nazivP'];
	$cijenaP = $input['cijenaP'];
	$kolicinaP = $input['kolicinaP'];
	$ukupnoP = $input['ukupnoP'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivP, $cijenaP, $kolicinaP, $ukupnoP);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Al tonno
//Check for Mandatory parameters
if(isset($input['nazivA']) && isset($input['cijenaA']) && isset($input['kolicinaA']) && isset($input['ukupnoA'])){
	$nazivA = $input['nazivA'];
	$cijenaA = $input['cijenaA'];
	$kolicinaA = $input['kolicinaA'];
	$ukupnoA = $input['ukupnoA'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivA, $cijenaA, $kolicinaA, $ukupnoA);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}

//Calzone
//Check for Mandatory parameters
if(isset($input['nazivZ']) && isset($input['cijenaZ']) && isset($input['kolicinaZ']) && isset($input['ukupnoZ'])){
	$nazivZ = $input['nazivZ'];
	$cijenaZ = $input['cijenaZ'];
	$kolicinaZ = $input['kolicinaZ'];
	$ukupnoZ = $input['ukupnoZ'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivZ, $cijenaZ, $kolicinaZ, $ukupnoZ);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}
//quattro formaggi
//Check for Mandatory parameters
if(isset($input['nazivQ']) && isset($input['cijenaQ']) && isset($input['kolicinaQ']) && isset($input['ukupnoQ'])){
	$nazivQ = $input['nazivQ'];
	$cijenaQ = $input['cijenaQ'];
	$kolicinaQ = $input['kolicinaQ'];
	$ukupnoQ = $input['ukupnoQ'];
	
	
	//Check if user already exist
//	if(!userExists($menu_item)){

		//Get a unique Salt
		//$salt         = getSalt();
		
		//Generate a unique password Hash
		//$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		//Query to register new user
		$insertQuery  = "INSERT INTO pizza_menu (naziv, cijena, kolicina, ukupno) VALUES (?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssss",$nazivQ, $cijenaQ, $kolicinaQ, $ukupnoQ);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "Menu item added";
			$stmt->close();
		}
	//}
	else{
		$response["status"] = 1;
		$response["message"] = "Menu item exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}
echo json_encode($response);
?>