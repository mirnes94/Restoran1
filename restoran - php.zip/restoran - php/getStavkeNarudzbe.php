<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restoran";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

mysqli_set_charset($conn, 'utf8');
$query = "SELECT * FROM pizza_menu";

$result = mysqli_query($conn,$query);
$number_of_rows=mysqli_num_rows($result);

$response=array();
if ($number_of_rows > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
 		
        $response[]=$row;

    }
   
} 
header('Content-Type: application/json');
echo json_encode(array("listaStavkiNarudzbe"=>$response));
mysqli_close($conn);
?>