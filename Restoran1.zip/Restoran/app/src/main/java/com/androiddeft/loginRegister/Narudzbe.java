package com.androiddeft.loginRegister;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ViewUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;

public class Narudzbe extends AppCompatActivity {

    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";

    private static final String KEY_EMPTY = "";
    private static final String KEY_DATUMN = "datumN";
    private static final String KEY_DATUMI= "datumI";
    private static final String KEY_KOLICINAN = "kolicinaN";

    private ProgressDialog pDialog;
    EditText etdatumN, etdatumI,etkolicinaN;


    private String datumN, datumI, kolicinaN;
   private String request_url=  "http://10.0.2.2/member/narudzba.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_narudzbe);

        etdatumN=findViewById(R.id.datumNarudzbe);
        etdatumI=findViewById(R.id.datumIsporuke);
        etkolicinaN=findViewById(R.id.kolicinaNarudzbe);

        Button narudzba = findViewById(R.id.potvrdiNarudzbu);
        narudzba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datumN=etdatumN.getText().toString().trim();
                datumI=etdatumI.getText().toString().trim();
                kolicinaN=etkolicinaN.getText().toString().trim();
               if(validateInputs()){
                createOrder();
                }
            }

        });


    }


    private boolean validateInputs() {
        if (KEY_EMPTY.equals(datumN)) {
            etdatumN.setError("Datum narudzbe ne moze biti prazan");
            etdatumN.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(datumI)) {
            etdatumI.setError("Datum isporuke ne moze biti prazan");
            etdatumI.requestFocus();
            return false;
        }

        if (KEY_EMPTY.equals(kolicinaN)) {
            etkolicinaN.setError("Brojac ne moze biti prazan");
            etkolicinaN.requestFocus();
            return false;
        }



        return true;
    }

    private void displayLoader() {
        pDialog = new ProgressDialog(Narudzbe.this);
        pDialog.setMessage("Adding data.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }
    private void createOrder() {
        displayLoader();
        JSONObject request = new JSONObject();
        try {
            request.put(KEY_DATUMN, datumN);
            request.put(KEY_DATUMI, datumI);
            request.put(KEY_KOLICINAN, kolicinaN);

        } catch ( JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                (Request.Method.POST, request_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();

                        try {
                            //Check if dish added successfully
                            if (response.getInt(KEY_STATUS) == 0) {
                                //Set the user session
                                Toast.makeText(getApplicationContext(),"Narudzba uspjesno kreirana", Toast.LENGTH_LONG).show();
                                //  session.loginUser(menu_item);
                                //loadDashboard();

                            }else if(response.getInt(KEY_STATUS) == 1){
                                Toast.makeText(getApplicationContext(),
                                        response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                      Toast.makeText(getApplicationContext(),
                               error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

        // Access the RequestQueue through your singleton class.


        MySingleton.getInstance(this).addToRequestQueue(jsArrayRequest);

    }

    public void backToOrder(View v){
        Intent i = new Intent(Narudzbe.this, MenuList.class);
        startActivity(i);
    }
    public void ZavrsiNarudzbu(View view) {
        Intent i = new Intent(getApplicationContext(), DashboardActivity.class);
        startActivity(i);
    }
    public void listaNarudzbi(View view){
        Intent intent = new Intent(getApplicationContext(), ListaNarudzbi.class);
        startActivity(intent);
    }
}
