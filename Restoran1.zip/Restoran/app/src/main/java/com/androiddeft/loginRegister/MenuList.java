package com.androiddeft.loginRegister;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MenuList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_list);
    }
   // public void pizzaAct(View view) {

        // ImageView pizza = (ImageView) findViewById(R.id.pizzaButton);
      //  Intent i = new Intent(MenuList.this, PizzaNarudzba.class);
       // startActivity(i);

   // }

    public void burgerAct(View view) {

        // ImageView burger = (ImageView) findViewById(R.id.BurgerButton);
        Intent i = new Intent(MenuList.this, Burger.class);
        startActivity(i);

    }
    public void pasteAct(View view) {

        //ImageView paste = (ImageView) findViewById(R.id.pastryButton);
        Intent i = new Intent(MenuList.this, Pasta.class);
        startActivity(i);

    }
    public void  cevapiAct(View view) {
        // ImageView cevapi = (ImageView) findViewById(R.id.cevapiButton);
        Intent i = new Intent(MenuList.this, Cevapi.class);
        startActivity(i);

    }

    public void  pitaAct(View view) {
        // ImageView pita = (ImageView) findViewById(R.id.pitaButton);
        Intent i = new Intent(MenuList.this, Pita.class);
        startActivity(i);

    }

    public void  sokAct(View view) {
        //  ImageView sok = (ImageView) findViewById(R.id.sokButton);
        Intent i = new Intent(MenuList.this, Sok.class);
        startActivity(i);

    }

    public void IdiNaPizzaNaruzdbu(View view) {
        //ImageView pizza = (ImageView) findViewById(R.id.pizzaButton);
        Intent i = new Intent(MenuList.this, PizzaNarudzba.class);
        startActivity(i);
    }
}
