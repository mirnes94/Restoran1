package com.androiddeft.loginRegister;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class StavkeNarudzbe extends AppCompatActivity {


    //margarita
    TextView nazivMargarita;
    String intentMargarita;

    TextView kolicinaMargarita;
    String intentKolicinaMargarita;

    TextView cijenaMargarita;
    String intentCijenaMargarita;


    TextView ukupnoMargarita;
    String intentUkupnoMargarita;

    //capricciosa
    TextView nazivCapricciosa;
    String intentCapricciosa;

    TextView kolicinaCapricciosa;
    String intentKolicinaCapricciosa;

    TextView cijenaCapricciosa;
    String intentCijenaCapricciosa;

    TextView ukupnoCapricciosa;
    String intentUkupnoCapricciosa;

    //funghi
    TextView nazivFunghi;
    String intentFunghi;

    TextView kolicinaFunghi;
    String intentKolicinaFunghi;

    TextView cijenaFunghi;
    String intentCijenaFunghi;

    TextView ukupnoFunghi;
    String intentUkupnoFunghi;

    //vegetariana
    TextView nazivVegetariana;
    String intentVegetariana;

    TextView kolicinaVegetariana;
    String intentKolicinaVegetariana;

    TextView cijenaVegetariana;
    String intentCijenaVegetariana;

    TextView ukupnoVegetariana;
    String intentUkupnoVegetariana;

    //hawaii
    TextView nazivHawaii;
    String intentHawaii;

    TextView kolicinaHawaii;
    String intentKolicinaHawaii;

    TextView cijenaHawaii;
    String intentCijenaHawaii;

    TextView ukupnoHawaii;
    String intentUkupnoHawaii;

    //bianca
    TextView nazivBianca;
    String intentBianca;

    TextView kolicinaBianca;
    String intentKolicinaBianca;

    TextView cijenaBianca;
    String intentCijenaBianca;

    TextView ukupnoBianca;
    String intentUkupnoBianca;

    //picante
    TextView nazivPicante;
    String intentPicante;

    TextView kolicinaPicante;
    String intentKolicinaPicante;

    TextView cijenaPicante;
    String intentCijenaPicante;

    TextView ukupnoPicante;
    String intentUkupnoPicante;

    //altonno
    TextView nazivAltonno;
    String intentAltonno;

    TextView kolicinaAltonno;
    String intentKolicinaAltonno;

    TextView cijenaAltonno;
    String intentCijenaAltonno;

    TextView ukupnoAltonno;
    String intentUkupnoAltonno;

    //calzone
    TextView nazivCalzone;
    String intentCalzone;

    TextView kolicinaCalzone;
    String intentKolicinaCalzone;

    TextView cijenaCalzone;
    String intentCijenaCalzone;

    TextView ukupnoCalzone;
    String intentUkupnoCalzone;

    //quattroformagi
    TextView nazivQuattroformaggi;
    String intentQuattroformaggi;

    TextView kolicinaQuattroformaggi;
    String intentKolicinaQuattroformaggi;

    TextView cijenaQuattroformaggi;
    String intentCijenaQuattroformaggi;

    TextView ukupnoQuattroformaggi;
    String intentUkupnoQuattroformaggi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stavke_narudzbe);

        //margarita
        nazivMargarita=(TextView)findViewById(R.id.textNazivMargarita);
        intentMargarita=getIntent().getExtras().getString("imeMargarita");
        nazivMargarita.setText(intentMargarita);

        kolicinaMargarita=(TextView)findViewById(R.id.textKolicinaMargarita);
        intentKolicinaMargarita=getIntent().getExtras().getString("kolicinaMargarita");
        kolicinaMargarita.setText(intentKolicinaMargarita);

        cijenaMargarita=(TextView)findViewById(R.id.textCijenaMargarita);
        intentCijenaMargarita=getIntent().getExtras().getString("cijenaMargarita");
        cijenaMargarita.setText(intentCijenaMargarita);

        ukupnoMargarita=(TextView) findViewById(R.id.textUkupnoMargarita);
        intentUkupnoMargarita=getIntent().getExtras().getString("ukupnoMargarita");
        ukupnoMargarita.setText(intentUkupnoMargarita);

        //capricciosa
        nazivCapricciosa=(TextView)findViewById(R.id.textNazivCapricciosa);
        intentCapricciosa=getIntent().getExtras().getString("imeCapricciosa");
        nazivCapricciosa.setText(intentCapricciosa);

        kolicinaCapricciosa=(TextView)findViewById(R.id.textKolicinaCapricciosa);
        intentKolicinaCapricciosa=getIntent().getExtras().getString("kolicinaCapricciosa");
        kolicinaCapricciosa.setText(intentKolicinaCapricciosa);

        cijenaCapricciosa=(TextView)findViewById(R.id.textCijenaCapricciosa);
        intentCijenaCapricciosa=getIntent().getExtras().getString("cijenaCapricciosa");
        cijenaCapricciosa.setText(intentCijenaCapricciosa);

        ukupnoCapricciosa=(TextView) findViewById(R.id.textUkupnoCapricciosa);
        intentUkupnoCapricciosa=getIntent().getExtras().getString("ukupnoCapricciosa");
        ukupnoCapricciosa.setText(intentUkupnoCapricciosa);

        //funghi
        nazivFunghi=(TextView)findViewById(R.id.textNazivFunghi);
        intentFunghi=getIntent().getExtras().getString("imeFunghi");
        nazivFunghi.setText(intentFunghi);

        kolicinaFunghi=(TextView)findViewById(R.id.textKolicinaFunghi);
        intentKolicinaFunghi=getIntent().getExtras().getString("kolicinaFunghi");
        kolicinaFunghi.setText(intentKolicinaFunghi);

        cijenaFunghi=(TextView)findViewById(R.id.textCijenaFunghi);
        intentCijenaFunghi=getIntent().getExtras().getString("cijenaFunghi");
        cijenaFunghi.setText(intentCijenaFunghi);

        ukupnoFunghi=(TextView) findViewById(R.id.textUkupnoFunghi);
        intentUkupnoFunghi=getIntent().getExtras().getString("ukupnoFunghi");
        ukupnoFunghi.setText(intentUkupnoFunghi);

        //vegetariana
        nazivVegetariana=(TextView)findViewById(R.id.textNazivVegetariana);
        intentVegetariana=getIntent().getExtras().getString("imeVegetariana");
        nazivVegetariana.setText(intentVegetariana);

        kolicinaVegetariana=(TextView)findViewById(R.id.textKolicinaVegetariana);
        intentKolicinaVegetariana=getIntent().getExtras().getString("kolicinaVegetariana");
        kolicinaVegetariana.setText(intentKolicinaVegetariana);

        cijenaVegetariana=(TextView)findViewById(R.id.textCijenaVegetariana);
        intentCijenaVegetariana=getIntent().getExtras().getString("cijenaVegetariana");
        cijenaVegetariana.setText(intentCijenaVegetariana);

        ukupnoVegetariana=(TextView) findViewById(R.id.textUkupnoVegetariana);
        intentUkupnoVegetariana=getIntent().getExtras().getString("ukupnoVegetariana");
        ukupnoVegetariana.setText(intentUkupnoVegetariana);

        //hawaii
        nazivHawaii=(TextView)findViewById(R.id.textNazivHawaii);
        intentHawaii=getIntent().getExtras().getString("imeHawaii");
        nazivHawaii.setText(intentHawaii);

        kolicinaHawaii=(TextView)findViewById(R.id.textKolicinaHawaii);
        intentKolicinaHawaii=getIntent().getExtras().getString("kolicinaHawaii");
        kolicinaHawaii.setText(intentKolicinaHawaii);

        cijenaHawaii=(TextView)findViewById(R.id.textCijenaHawaii);
        intentCijenaHawaii=getIntent().getExtras().getString("cijenaHawaii");
        cijenaHawaii.setText(intentCijenaHawaii);

        ukupnoHawaii=(TextView) findViewById(R.id.textUkupnoHawaii);
        intentUkupnoHawaii=getIntent().getExtras().getString("ukupnoHawaii");
        ukupnoHawaii.setText(intentUkupnoHawaii);

        //bianca
        nazivBianca=(TextView)findViewById(R.id.textNazivBianca);
        intentBianca=getIntent().getExtras().getString("imeBianca");
        nazivBianca.setText(intentBianca);

        kolicinaBianca=(TextView)findViewById(R.id.textKolicinaBianca);
        intentKolicinaBianca=getIntent().getExtras().getString("kolicinaBianca");
        kolicinaBianca.setText(intentKolicinaBianca);

        cijenaBianca=(TextView)findViewById(R.id.textCijenaBianca);
        intentCijenaBianca=getIntent().getExtras().getString("cijenaBianca");
        cijenaBianca.setText(intentCijenaBianca);

        ukupnoBianca=(TextView) findViewById(R.id.textUkupnoBianca);
        intentUkupnoBianca=getIntent().getExtras().getString("ukupnoBianca");
        ukupnoBianca.setText(intentUkupnoBianca);

        //picante
        nazivPicante=(TextView)findViewById(R.id.textNazivPicante);
        intentPicante=getIntent().getExtras().getString("imePicante");
        nazivPicante.setText(intentPicante);

        kolicinaPicante=(TextView)findViewById(R.id.textKolicinaPicante);
        intentKolicinaPicante=getIntent().getExtras().getString("kolicinaPicante");
        kolicinaPicante.setText(intentKolicinaPicante);

        cijenaPicante=(TextView)findViewById(R.id.textCijenaPicante);
        intentCijenaPicante=getIntent().getExtras().getString("cijenaPicante");
        cijenaPicante.setText(intentCijenaPicante);

        ukupnoPicante=(TextView) findViewById(R.id.textUkupnoPicante);
        intentUkupnoPicante=getIntent().getExtras().getString("ukupnoPicante");
        ukupnoPicante.setText(intentUkupnoPicante);

        //altonno
        nazivAltonno=(TextView)findViewById(R.id.textNazivAltonno);
        intentAltonno=getIntent().getExtras().getString("imeAltonno");
        nazivAltonno.setText(intentAltonno);

        kolicinaAltonno=(TextView)findViewById(R.id.textKolicinaAltonno);
        intentKolicinaAltonno=getIntent().getExtras().getString("kolicinaAltonno");
        kolicinaAltonno.setText(intentKolicinaAltonno);

        cijenaAltonno=(TextView)findViewById(R.id.textCijenaAltonno);
        intentCijenaAltonno=getIntent().getExtras().getString("cijenaAltonno");
        cijenaAltonno.setText(intentCijenaAltonno);

        ukupnoAltonno=(TextView) findViewById(R.id.textUkupnoAltonno);
        intentUkupnoAltonno=getIntent().getExtras().getString("ukupnoAltonno");
        ukupnoAltonno.setText(intentUkupnoAltonno);

        //calzone
        nazivCalzone=(TextView)findViewById(R.id.textNazivCalzone);
        intentCalzone=getIntent().getExtras().getString("imeCalzone");
        nazivCalzone.setText(intentCalzone);

        kolicinaCalzone=(TextView)findViewById(R.id.textKolicinaCalzone);
        intentKolicinaCalzone=getIntent().getExtras().getString("kolicinaCalzone");
        kolicinaCalzone.setText(intentKolicinaCalzone);

        cijenaCalzone=(TextView)findViewById(R.id.textCijenaCalzone);
        intentCijenaCalzone=getIntent().getExtras().getString("cijenaCalzone");
        cijenaCalzone.setText(intentCijenaCalzone);

        ukupnoCalzone=(TextView) findViewById(R.id.textUkupnoCalzone);
        intentUkupnoCalzone=getIntent().getExtras().getString("ukupnoCalzone");
        ukupnoCalzone.setText(intentUkupnoCalzone);

        //quattro formagi
        nazivQuattroformaggi=(TextView)findViewById(R.id.textNazivQuattroformaggi);
        intentQuattroformaggi=getIntent().getExtras().getString("imeQuattroformaggi");
        nazivQuattroformaggi.setText(intentQuattroformaggi);

        kolicinaQuattroformaggi=(TextView)findViewById(R.id.textKolicinaQuattroformaggi);
        intentKolicinaQuattroformaggi=getIntent().getExtras().getString("kolicinaQuattroformaggi");
        kolicinaQuattroformaggi.setText(intentKolicinaQuattroformaggi);

        cijenaQuattroformaggi=(TextView)findViewById(R.id.textCijenaQuattroformaggi);
        intentCijenaQuattroformaggi=getIntent().getExtras().getString("cijenaQuattroformaggi");
        cijenaQuattroformaggi.setText(intentCijenaQuattroformaggi);

        ukupnoQuattroformaggi=(TextView) findViewById(R.id.textUkupnoQuattroformaggi);
        intentUkupnoQuattroformaggi=getIntent().getExtras().getString("ukupnoQuattroformaggi");
        ukupnoQuattroformaggi.setText(intentUkupnoQuattroformaggi);

    }

}
