package com.androiddeft.loginRegister;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
//import com.example.loginRegister.R;

import org.json.JSONException;
import org.json.JSONObject;


public class PizzaNarudzba extends AppCompatActivity {



    private static final String KEY_STATUS = "status";
    private static final String KEY_MESSAGE = "message";

    private static final String KEY_NAZIVM = "nazivM";
    private static final String KEY_CIJENAM= "cijenaM";
    private static final String KEY_KOLICINAM = "kolicinaM";
    private static final String KEY_UKUPNOM = "ukupnoM";

    private static final String KEY_NAZIVC = "nazivC";
    private static final String KEY_CIJENAC= "cijenaC";
    private static final String KEY_KOLICINAC = "kolicinaC";
    private static final String KEY_UKUPNOC = "ukupnoC";

    private static final String KEY_NAZIVF = "nazivF";
    private static final String KEY_CIJENAF= "cijenaF";
    private static final String KEY_KOLICINAF = "kolicinaF";
    private static final String KEY_UKUPNOF = "ukupnoF";

    private static final String KEY_NAZIVV = "nazivV";
    private static final String KEY_CIJENAV= "cijenaV";
    private static final String KEY_KOLICINAV = "kolicinaV";
    private static final String KEY_UKUPNOV = "ukupnoV";

    private static final String KEY_NAZIVH = "nazivH";
    private static final String KEY_CIJENAH= "cijenaH";
    private static final String KEY_KOLICINAH = "kolicinaH";
    private static final String KEY_UKUPNOH = "ukupnoH";

    private static final String KEY_NAZIVB = "nazivB";
    private static final String KEY_CIJENAB= "cijenaB";
    private static final String KEY_KOLICINAB = "kolicinaB";
    private static final String KEY_UKUPNOB = "ukupnoB";

    private static final String KEY_NAZIVP = "nazivP";
    private static final String KEY_CIJENAP= "cijenaP";
    private static final String KEY_KOLICINAP = "kolicinaP";
    private static final String KEY_UKUPNOP = "ukupnoP";

    private static final String KEY_NAZIVA = "nazivA";
    private static final String KEY_CIJENAA= "cijenaA";
    private static final String KEY_KOLICINAA = "kolicinaA";
    private static final String KEY_UKUPNOA = "ukupnoA";

    private static final String KEY_NAZIVZ = "nazivZ";
    private static final String KEY_CIJENAZ= "cijenaZ";
    private static final String KEY_KOLICINAZ = "kolicinaZ";
    private static final String KEY_UKUPNOZ = "ukupnoZ";

    private static final String KEY_NAZIVQ = "nazivQ";
    private static final String KEY_CIJENAQ= "cijenaQ";
    private static final String KEY_KOLICINAQ = "kolicinaQ";
    private static final String KEY_UKUPNOQ = "ukupnoQ";

    private static final String KEY_EMPTY = "";

    private Switch etNazivMargarita;
    private TextView etCijenaMargarita;
    private TextView etKolicinaMargarita;

    private Switch etNazivCapricciosa;
    private TextView etCijenaCapricciosa;
    private TextView etKolicinaCapricciosa;

    private Switch etNazivFunghi;
    private TextView etCijenaFunghi;
    private TextView etKolicinaFunghi;

    private Switch etNazivVegetariana;
    private TextView etCijenaVegetariana;
    private TextView etKolicinaVegetariana;

    private Switch etNazivHawaii;
    private TextView etCijenaHawaii;
    private TextView etKolicinaHawaii;

    private Switch etNazivBianca;
    private TextView etCijenaBianca;
    private TextView etKolicinaBianca;

    private Switch etNazivPicante;
    private TextView etCijenaPicante;
    private TextView etKolicinaPicante;

    private Switch etNazivAltonno;
    private TextView etCijenaAltonno;
    private TextView etKolicinaAltonno;

    private Switch etNazivCalzone;
    private TextView etCijenaCalzone;
    private TextView etKolicinaCalzone;

    private Switch etNazivQuattroformaggi;
    private TextView etCijenaQuattroformaggi;
    private TextView etKolicinaQuattroformaggi;

    private String nazivM, cijenaM, kolicinaM, ukupnoM;
    private String nazivC, cijenaC, kolicinaC, ukupnoC;
    private String nazivF, cijenaF, kolicinaF, ukupnoF;
    private String nazivV, cijenaV, kolicinaV, ukupnoV;
    private String nazivH, cijenaH, kolicinaH, ukupnoH;
    private String nazivB, cijenaB, kolicinaB, ukupnoB;
    private String nazivP, cijenaP, kolicinaP, ukupnoP;
    private String nazivA, cijenaA, kolicinaA, ukupnoA;
    private String nazivZ, cijenaZ, kolicinaZ, ukupnoZ;
    private String nazivQ, cijenaQ, kolicinaQ, ukupnoQ;

    private ProgressDialog pDialog;
    private String register_url =  "http://10.0.2.2/member/pizza_menu.php";
    private SessionHandler session;
    //---------------


    double doubleSumMargarita;
    double doubleSumCapricciosa;
    double doubleSumFunghi;
    double doubleSumVegetariana;
    double doubleSumHawaii;
    double doubleSumBianca;
    double doubleSumPicante;
    double doubleSumAltonno;
    double doubleSumCalzone;
    double doubleSumQuattroformagi;

    int margaritacount=0;
    int capricciosacount=0;
    int funghicount=0;
    int hawaiicount=0;
    int biancacount=0;
    int picantecount=0;
    int altonnocount=0;
    int calzonecount=0;
    int vegetarianacount=0;
    int quanttroformaggicount=0;

    boolean strMargarita=false;
    boolean strCapriciosa=false;
    boolean strFunghi=false;
    boolean strHawaii=false;
    boolean strBianca=false;
    boolean strPicante=false;
    boolean strAltonno=false;
    boolean strCalzone=false;
    boolean strVegetariana=false;
    boolean strQuattroFormagi=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_narudzba);

        etNazivMargarita = findViewById(R.id.margarita);
        etCijenaMargarita = findViewById(R.id.cijenaMargarita);
        etKolicinaMargarita = findViewById(R.id.countMargarita);

        etNazivCapricciosa = findViewById(R.id.capriciosa);
        etCijenaCapricciosa = findViewById(R.id.cijenaCapriciosa);
        etKolicinaCapricciosa = findViewById(R.id.countCapricciosa);

        etNazivFunghi = findViewById(R.id.funghi);
        etCijenaFunghi = findViewById(R.id.cijenaFunghi);
        etKolicinaFunghi = findViewById(R.id.countFunghi);

        etNazivVegetariana = findViewById(R.id.vegetarijana);
        etCijenaVegetariana = findViewById(R.id.cijenaVegetarijana);
        etKolicinaVegetariana = findViewById(R.id.countVegetariana);

        etNazivHawaii = findViewById(R.id.hawai);
        etCijenaHawaii = findViewById(R.id.cijenaHawaii);
        etKolicinaHawaii = findViewById(R.id.countHawaii);

        etNazivBianca = findViewById(R.id.bianca);
        etCijenaBianca = findViewById(R.id.cijenaBianca);
        etKolicinaBianca = findViewById(R.id.countBianca);

        etNazivPicante = findViewById(R.id.picante);
        etCijenaPicante = findViewById(R.id.cijenaPicante);
        etKolicinaPicante = findViewById(R.id.countPicante);

        etNazivAltonno = findViewById(R.id.altonno);
        etCijenaAltonno = findViewById(R.id.cijenaAltonno);
        etKolicinaAltonno = findViewById(R.id.countAltonno);

        etNazivCalzone = findViewById(R.id.calzone);
        etCijenaCalzone = findViewById(R.id.cijenaCalzone);
        etKolicinaCalzone = findViewById(R.id.countCalzone);

        etNazivQuattroformaggi = findViewById(R.id.quatrofurmagi);
        etCijenaQuattroformaggi = findViewById(R.id.cijenaQuattroFormagi);
        etKolicinaQuattroformaggi = findViewById(R.id.countQuattroFormagi);

        Button registerOrder = findViewById(R.id.buttonPizzaNarudzba);
        registerOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Retrieve the data entered in the edit texts
                nazivM= etNazivMargarita.getText().toString().toLowerCase().trim();
                cijenaM = etCijenaMargarita.getText().toString().trim();
                kolicinaM = etKolicinaMargarita.getText().toString().trim();
                doubleSumMargarita = Double.parseDouble(cijenaM) * Double.parseDouble(kolicinaM);
                ukupnoM = String.valueOf(doubleSumMargarita);

                nazivC= etNazivCapricciosa.getText().toString().toLowerCase().trim();
                cijenaC = etCijenaCapricciosa.getText().toString().trim();
                kolicinaC = etKolicinaCapricciosa.getText().toString().trim();
                doubleSumCapricciosa = Double.parseDouble(cijenaC) * Double.parseDouble(kolicinaC);
                ukupnoC = String.valueOf(doubleSumCapricciosa);

                nazivF= etNazivFunghi.getText().toString().toLowerCase().trim();
                cijenaF = etCijenaFunghi.getText().toString().trim();
                kolicinaF = etKolicinaFunghi.getText().toString().trim();
                doubleSumFunghi = Double.parseDouble(cijenaF) * Double.parseDouble(kolicinaF);
                ukupnoF = String.valueOf(doubleSumFunghi);

                nazivV= etNazivVegetariana.getText().toString().toLowerCase().trim();
                cijenaV = etCijenaVegetariana.getText().toString().trim();
                kolicinaV = etKolicinaVegetariana.getText().toString().trim();
                doubleSumVegetariana = Double.parseDouble(cijenaV) * Double.parseDouble(kolicinaV);
                ukupnoV = String.valueOf(doubleSumVegetariana);

                nazivH= etNazivHawaii.getText().toString().toLowerCase().trim();
                cijenaH = etCijenaHawaii.getText().toString().trim();
                kolicinaH = etKolicinaHawaii.getText().toString().trim();
                doubleSumHawaii = Double.parseDouble(cijenaH) * Double.parseDouble(kolicinaH);
                ukupnoH = String.valueOf(doubleSumHawaii);

                nazivB= etNazivBianca.getText().toString().toLowerCase().trim();
                cijenaB = etCijenaBianca.getText().toString().trim();
                kolicinaB = etKolicinaBianca.getText().toString().trim();
                doubleSumBianca = Double.parseDouble(cijenaB) * Double.parseDouble(kolicinaB);
                ukupnoB = String.valueOf(doubleSumBianca);

                nazivP= etNazivPicante.getText().toString().toLowerCase().trim();
                cijenaP = etCijenaPicante.getText().toString().trim();
                kolicinaP = etKolicinaPicante.getText().toString().trim();
                doubleSumPicante = Double.parseDouble(cijenaP) * Double.parseDouble(kolicinaP);
                ukupnoP = String.valueOf(doubleSumPicante);

                nazivA= etNazivAltonno.getText().toString().toLowerCase().trim();
                cijenaA = etCijenaAltonno.getText().toString().trim();
                kolicinaA = etKolicinaAltonno.getText().toString().trim();
                doubleSumAltonno = Double.parseDouble(cijenaA) * Double.parseDouble(kolicinaA);
                ukupnoA = String.valueOf(doubleSumAltonno);

                nazivZ= etNazivCalzone.getText().toString().toLowerCase().trim();
                cijenaZ = etCijenaCalzone.getText().toString().trim();
                kolicinaZ = etKolicinaCalzone.getText().toString().trim();
                doubleSumCalzone = Double.parseDouble(cijenaZ) * Double.parseDouble(kolicinaZ);
                ukupnoZ = String.valueOf(doubleSumCalzone);

                nazivQ= etNazivQuattroformaggi.getText().toString().toLowerCase().trim();
                cijenaQ = etCijenaQuattroformaggi.getText().toString().trim();
                kolicinaQ = etKolicinaQuattroformaggi.getText().toString().trim();
                doubleSumQuattroformagi = Double.parseDouble(cijenaQ) * Double.parseDouble(kolicinaQ);
                ukupnoQ = String.valueOf(doubleSumQuattroformagi);

                 //if (validateInputs()) {
                registerOrder();
                // }

            }

        });


        Switch margaritaSwitch=(Switch)findViewById(R.id.margarita);
        Switch capriciosaSwitch=(Switch)findViewById(R.id.capriciosa);
        Switch funghiSwitch=(Switch)findViewById(R.id.funghi);
        Switch vegetarianaSwitch=(Switch)findViewById(R.id.vegetarijana);
        Switch hawaiiSwitch=(Switch)findViewById(R.id.hawai);
        Switch biancaSwitch=(Switch)findViewById(R.id.bianca);
        Switch picanteSwitch=(Switch)findViewById(R.id.picante);
        Switch altonnoSwitch=(Switch)findViewById(R.id.altonno);
        Switch calzoneSwitch=(Switch)findViewById(R.id.calzone);
        Switch quattroformagiSwitch=(Switch)findViewById(R.id.quatrofurmagi);

        margaritaSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strMargarita=true;
                }
                else
                {
                    strMargarita=false;
                }

            }


        });
        capriciosaSwitch.setOnCheckedChangeListener(new  CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strCapriciosa=true;
                }
                else
                {
                    strCapriciosa=false;
                }

            }
        });
        funghiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strFunghi=true;
                }
                else
                {
                    strFunghi=false;
                }

            }
        });
        vegetarianaSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strVegetariana=true;
                }
                else
                {
                    strVegetariana=false;
                }

            }
        });
        hawaiiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strHawaii=true;
                }
                else
                {
                    strHawaii=false;
                }

            }
        });
        biancaSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strBianca=true;
                }
                else
                {
                    strBianca=false;
                }

            }
        });
        picanteSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strPicante=true;
                }
                else
                {
                    strPicante=false;
                }

            }
        });
        altonnoSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strAltonno=true;
                }
                else
                {
                    strAltonno=false;
                }

            }
        });
        calzoneSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strCalzone=true;
                }
                else
                {
                    strCalzone=false;
                }

            }
        });
        quattroformagiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    strQuattroFormagi=true;
                }
                else
                {
                    strQuattroFormagi=false;
                }

            }
        });




    }

    private void displayLoader() {
        pDialog = new ProgressDialog(PizzaNarudzba.this);
        pDialog.setMessage("Adding data.. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();

    }


    private void registerOrder() {
        displayLoader();
        JSONObject request = new JSONObject();
        try {
            //margarita
            if(Integer.parseInt(etKolicinaMargarita.getText().toString())>0){
            request.put(KEY_NAZIVM, nazivM);
            request.put(KEY_CIJENAM, cijenaM);
            request.put(KEY_KOLICINAM, kolicinaM);
            request.put(KEY_UKUPNOM, ukupnoM);
            }

            if(Integer.parseInt(etKolicinaCapricciosa.getText().toString())>0) {
                //capriciosa
                request.put(KEY_NAZIVC, nazivC);
                request.put(KEY_CIJENAC, cijenaC);
                request.put(KEY_KOLICINAC, kolicinaC);
                request.put(KEY_UKUPNOC, ukupnoC);
            }
            if(Integer.parseInt(etKolicinaFunghi.getText().toString())>0) {
                //funghi
                request.put(KEY_NAZIVF, nazivF);
                request.put(KEY_CIJENAF, cijenaF);
                request.put(KEY_KOLICINAF, kolicinaF);
                request.put(KEY_UKUPNOF, ukupnoF);
            }
            if(Integer.parseInt(etKolicinaVegetariana.getText().toString())>0) {
                //vegetariana
                request.put(KEY_NAZIVV, nazivV);
                request.put(KEY_CIJENAV, cijenaV);
                request.put(KEY_KOLICINAV, kolicinaV);
                request.put(KEY_UKUPNOV, ukupnoV);
            }
            if(Integer.parseInt(etKolicinaHawaii.getText().toString())>0) {
                //hawaii
                request.put(KEY_NAZIVH, nazivH);
                request.put(KEY_CIJENAH, cijenaH);
                request.put(KEY_KOLICINAH, kolicinaH);
                request.put(KEY_UKUPNOH, ukupnoH);
            }
            if(Integer.parseInt(etKolicinaBianca.getText().toString())>0) {
                //bianca
                request.put(KEY_NAZIVB, nazivB);
                request.put(KEY_CIJENAB, cijenaB);
                request.put(KEY_KOLICINAB, kolicinaB);
                request.put(KEY_UKUPNOB, ukupnoB);
            }
            //picante
            if(Integer.parseInt(etKolicinaPicante.getText().toString())>0) {
                request.put(KEY_NAZIVP, nazivP);
                request.put(KEY_CIJENAP, cijenaP);
                request.put(KEY_KOLICINAP, kolicinaP);
                request.put(KEY_UKUPNOP, ukupnoP);
            }
            //altonno
           if(Integer.valueOf(etKolicinaAltonno.getText().toString())>0) {
                request.put(KEY_NAZIVA, nazivA);
                request.put(KEY_CIJENAA, cijenaA);
                request.put(KEY_KOLICINAA, kolicinaA);
                request.put(KEY_UKUPNOA, ukupnoA);
           }
            if(Integer.parseInt(etKolicinaCalzone.getText().toString())>0) {
                request.put(KEY_NAZIVZ, nazivZ);
                request.put(KEY_CIJENAZ, cijenaZ);
                request.put(KEY_KOLICINAZ, kolicinaZ);
                request.put(KEY_UKUPNOZ, ukupnoZ);
            }
            if(Integer.parseInt(etKolicinaQuattroformaggi.getText().toString())>0) {
                request.put(KEY_NAZIVQ, nazivQ);
                request.put(KEY_CIJENAQ, cijenaQ);
                request.put(KEY_KOLICINAQ, kolicinaQ);
                request.put(KEY_UKUPNOQ, ukupnoQ);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsArrayRequest = new JsonObjectRequest
                (Request.Method.POST, register_url, request, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pDialog.dismiss();

                        try {
                            //Check if dish added successfully
                            if (response.getInt(KEY_STATUS) == 0) {
                                //Set the user session
                                Toast.makeText(getApplicationContext(),"Stavke jela dodane", Toast.LENGTH_LONG).show();
                                //  session.loginUser(menu_item);
                                //   loadDashboard();

                            }else if(response.getInt(KEY_STATUS) == 1){
                                //Display error message if username is already existsing
                                etNazivMargarita.setError("Menu item already added!");
                                etNazivMargarita.requestFocus();

                            }else if(response.getInt(KEY_STATUS) == 2) {
                                Toast.makeText(getApplicationContext(),
                                        response.getString(KEY_MESSAGE), Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();

                        //Display error message whenever an error occurs
                        Toast.makeText(getApplicationContext(),
                                error.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

        // Access the RequestQueue through your singleton class.


        MySingleton.getInstance(this).addToRequestQueue(jsArrayRequest);
    }

    /**
     * Validates inputs and shows error if any
     * @return
     */
  /*  private boolean validateInputs() {
        if (KEY_EMPTY.equals(naziv)) {
            etNaziv.setError("Name cannot be empty");
            etNaziv.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(cijena)) {
            etCijena.setError("Price cannot be empty");
            etCijena.requestFocus();
            return false;

        }

        if (KEY_EMPTY.equals(kolicina)) {
            etKolicina.setError("Count cannot be empty");
            etKolicina.requestFocus();
            return false;
        }



        return true;
    }
*/
    public void plusMargarita (View view){
        TextView margarita = (TextView) findViewById(R.id.countMargarita);
        if(strMargarita) {
            margaritacount++;
        }
        margarita.setText(String.valueOf(margaritacount));


    }
    public void minusMargarita (View view){

        TextView margarita = (TextView) findViewById(R.id.countMargarita);
        if(strMargarita) {
            if (margaritacount > 0) {
                margaritacount--;
            }
        }
        margarita.setText(String.valueOf(margaritacount));

    }
    //capriciosa
    public void plusCapricciosa(View view){
        TextView capricciosa= (TextView)findViewById(R.id.countCapricciosa);
        if(strCapriciosa){
            capricciosacount++;}
        capricciosa.setText(String.valueOf(capricciosacount));


    }
    public void minusCapricciosa(View view){
        TextView capricciosa= (TextView)findViewById(R.id.countCapricciosa);
        if(strCapriciosa) {
            if (capricciosacount > 0) {
                capricciosacount--;
            }
        }
        capricciosa.setText(String.valueOf(capricciosacount));
    }

    //funghi
    public void plusFunghi(View view){
        TextView funghi= (TextView)findViewById(R.id.countFunghi);
        if(strFunghi){
            funghicount++;}
        funghi.setText(String.valueOf(funghicount));


    }
    public void minusFunghi(View view){
        TextView funghi= (TextView)findViewById(R.id.countFunghi);
        if(strFunghi){
            if(funghicount>0){
                funghicount--;
            }}
        funghi.setText(String.valueOf(funghicount));
    }

    //vegetariana
    public void plusVegetariana(View view){
        TextView vegetariana= (TextView)findViewById(R.id.countVegetariana);
        if(strVegetariana){
            vegetarianacount++;}
        vegetariana.setText(String.valueOf(vegetarianacount));


    }
    public void minusVegetariana(View view){
        TextView vegetariana= (TextView)findViewById(R.id.countVegetariana);
        if(strVegetariana) {
            if (vegetarianacount > 0) {
                vegetarianacount--;
            }
        }
        vegetariana.setText(String.valueOf(vegetarianacount));


    }

    //hawaii

    public void plusHawaii(View view){
        TextView hawaii= (TextView)findViewById(R.id.countHawaii);
        if(strHawaii){
            hawaiicount++;}
        hawaii.setText(String.valueOf(hawaiicount));
    }
    public void minusHawaii(View view){
        TextView hawaii= (TextView)findViewById(R.id.countHawaii);
        if(strHawaii){
            if(hawaiicount>0) {
                hawaiicount--;
            }}
        hawaii.setText(String.valueOf(hawaiicount));
    }

    //bianca
    public void plusBianca(View view){
        TextView bianca= (TextView)findViewById(R.id.countBianca);
        if(strBianca) {
            biancacount++;
        }
        bianca.setText(String.valueOf(biancacount));
    }
    public void minusBianca(View view){
        TextView bianca= (TextView)findViewById(R.id.countBianca);
        if(strBianca) {
            if (biancacount > 0) {
                biancacount--;
            }
        }
        bianca.setText(String.valueOf(biancacount));
    }

    //picante
    public void plusPicante(View view){
        TextView picante= (TextView)findViewById(R.id.countPicante);
        if(strPicante) {
            picantecount++;
        }
        picante.setText(String.valueOf(picantecount));
    }
    public void minusPicante(View view){
        TextView picante= (TextView)findViewById(R.id.countPicante);
        if(strPicante) {
            if (picantecount > 0) {
                picantecount--;
            }
        }
        picante.setText(String.valueOf(picantecount));
    }

    //altonno

    public void plusAltonno(View view){
        TextView altonno= (TextView)findViewById(R.id.countAltonno);
        if(strAltonno) {
            altonnocount++;
        }
        altonno.setText(String.valueOf(altonnocount));
    }
    public void minusAltonno(View view){
        TextView altonno= (TextView)findViewById(R.id.countAltonno);
        if(strAltonno) {
            if (altonnocount > 0) {
                altonnocount--;
            }
        }
        altonno.setText(String.valueOf(altonnocount));
    }

    //calzone

    public void plusCalzone(View view) {
        TextView calzone = (TextView) findViewById(R.id.countCalzone);
        if(strCalzone) {
            calzonecount++;
        }
        calzone.setText(String.valueOf(calzonecount));
    }

    public void minusCalzone(View view) {

        TextView calzone = (TextView) findViewById(R.id.countCalzone);
        if(strCalzone){
            if(calzonecount>0){
                calzonecount--;}
        }
        calzone.setText(String.valueOf(calzonecount));
    }

    //quattro formaggi

    public void plusQuattroFormagi(View view) {
        TextView quattroformagi = (TextView) findViewById(R.id.countQuattroFormagi);
        if(strQuattroFormagi){
            quanttroformaggicount++;}
        quattroformagi.setText(String.valueOf(quanttroformaggicount));
    }
    public void minusQuattroFormagi(View view) {
        TextView quattroformagi = (TextView) findViewById(R.id.countQuattroFormagi);
        if(strQuattroFormagi) {
            if (quanttroformaggicount > 0) {
                quanttroformaggicount--;
            }
        }
        quattroformagi.setText(String.valueOf(quanttroformaggicount));
    }

    public void idiDalje(View v){
        Intent i = new Intent(PizzaNarudzba.this,Narudzbe.class);
        startActivity(i);
    }
}
