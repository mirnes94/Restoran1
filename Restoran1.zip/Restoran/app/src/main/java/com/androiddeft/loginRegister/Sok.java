package com.androiddeft.loginRegister;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Sok extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sok);
    }
}
